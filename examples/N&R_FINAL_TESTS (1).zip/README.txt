Hello :)
This is a test for HW3.
Please make sure that you add your submission files into this folder.


folder structure : 

HW3_tests ->

			examples

			inputs
				one two three four random

			outputs		
				one two three four random

			valgrind_tests

			dflow.... (submission files include MAKEFILE!!!!!!)

			run.sh


In order to check memory leaks using valgrind uncomment the lines in the script.

STEPS:

make clean
make
./run.sh

Hope you all pass :D














Test written by Yuval Rosman with the help of Nimrod Blecher